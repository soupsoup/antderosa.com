<?php
/**
 * Template Name: Lime Ticker Section
 *
 * A generic rows page (AI Builds, Podcasts, Newsletters, Launches…)
 * whose content is edited entirely in the WordPress page editor.
 *
 * - The page TITLE renders as the giant headline.
 * - The page EXCERPT (sidebar → Excerpt) renders as the intro line.
 * - The page CONTENT renders on the cream panel. Starter block markup
 *   for each section lives in the theme's page-content/ folder — paste
 *   it into the page's code editor view, then edit visually forever after.
 */
get_header();
?>

<main>
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="lt-section lt-wrap">
			<h1 class="lt-h1 lt-h1--page"><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?>
				<p class="lt-lede"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
		</div>
		<div class="lt-panel lt-section">
			<div class="lt-wrap lt-rows">
				<?php the_content(); ?>
			</div>
		</div>
	<?php endwhile; ?>
</main>

<?php get_footer(); ?>
