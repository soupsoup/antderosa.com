# Lime Ticker — WordPress theme

A bold-type redesign of antderosa.com: chartreuse background, giant Archivo Black headlines, marquee ticker.

## Install

1. Zip the `limeticker` folder (or use the zip you downloaded).
2. In WordPress admin: **Appearance → Themes → Add New → Upload Theme**, choose the zip, install, then **Activate**.
   - Tip: use a staging site or the **Live Preview** button first — this doesn't touch your current theme until you activate.

## Set up (5 minutes)

1. **Menu** — Appearance → Menus: create a menu with Home, Bio, Portfolio, Testimonials, AI Builds, Podcasts, Newsletters, Launches, Newsletter, Contact and assign it to the **Primary Menu** location. Without one, the theme falls back to a plain page list.
   - To style Contact as the black pill button, add the CSS class `lt-nav-cta` to that menu item (enable "CSS Classes" under Screen Options).
2. **Homepage** — Settings → Reading → set "Your homepage displays" to a static page. Any page works; the theme's `front-page.php` renders the hero/ticker/stats layout regardless of that page's content.
3. **Pages** — Bio, Testimonials, Contact, Tech Stack render through the new skin automatically (giant title + cream panel). Blockquotes get the big-type testimonial treatment, so the Testimonials page looks right as-is.
4. **New sections (v1.2)** — AI Builds, Podcasts, Newsletters, and Launches are edited entirely in the page editor:
   1. Pages → Add New, name it (e.g. "AI Builds").
   2. Under **Page Attributes → Template**, pick **Lime Ticker Section**.
   3. In the editor's ⋮ menu, switch to **Code editor** and paste the contents of the matching file from the theme's `page-content/` folder (`ai-builds.html`, `podcasts.html`, `newsletters.html`, `launches.html`). Switch back to the visual editor — everything is now normal blocks you can edit, duplicate, and reorder.
   4. Set the page **Excerpt** (sidebar) — it renders as the intro line under the big title. Suggested excerpts are noted at the top of each `page-content` file.
   5. Publish and add the page to the menu.
   - To add a new item later: duplicate a row Group block in the editor and edit its text/links. No code needed.
5. **Blog (v1.3)** — Pages → Add New, name it "Blog", set **Page Attributes → Template** to **Blog (latest post)**, publish, and add it to the menu. Clicking Blog jumps straight to the most recent post; every post gets ← Newer / Older → buttons at the bottom to page through the archive.

## Customizing

- Hero headline, stats, ticker text, and homepage quote: edit `front-page.php` (plain HTML, clearly commented).
- Footer CTA + social links: `footer.php`.
- Colors: CSS variables at the top of `style.css` (`--lt-lime`, `--lt-ink`, `--lt-panel`).
- Headshot: replace `images/anthony.png`.

## Notes

- The contact form on the prototype was a mock — keep using your existing contact form plugin/shortcode on the Contact page.
- Google Fonts (Archivo + Archivo Black) load from fonts.googleapis.com. Self-host them later if you prefer.
