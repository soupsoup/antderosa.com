<?php
/**
 * Front page: hero, ticker, stats, quote, section cards.
 * Edit the hardcoded copy here, or wire sections to the Customizer later.
 */
get_header();
?>

<main>
	<div class="lt-hero lt-wrap">
		<div class="lt-hero-copy">
			<h1 class="lt-h1">I build<br>editorial ops<br>from zero.</h1>
			<p>With over 20 years of experience in digital media, I have a proven track record of leading content and product teams at newsrooms and media organizations, including Reuters, Circa, and the Wall Street Journal.</p>
			<div class="lt-btn-row">
				<a class="lt-btn lt-btn--solid" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Get in touch</a>
				<a class="lt-btn lt-btn--outline" href="<?php echo esc_url( home_url( '/bio/' ) ); ?>">About me</a>
			</div>
		</div>
		<img class="lt-hero-photo" src="<?php echo esc_url( get_template_directory_uri() . '/images/anthony.png' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
	</div>

	<div class="lt-ticker" aria-hidden="true">
		<div class="lt-ticker-track">
			<span>Emmy Award &#10022; Cannes Lions Grand Prix &#10022; Clio Award &#10022; &ldquo;The undisputed King of Tumblr&rdquo; &mdash; The New York Times &#10022; Journalist of the Year &mdash; El Mundo &#10022; Cited in the NYT Digital Innovation Report &#10022; </span><span>Emmy Award &#10022; Cannes Lions Grand Prix &#10022; Clio Award &#10022; &ldquo;The undisputed King of Tumblr&rdquo; &mdash; The New York Times &#10022; Journalist of the Year &mdash; El Mundo &#10022; Cited in the NYT Digital Innovation Report &#10022; </span>
		</div>
	</div>

	<div class="lt-grid lt-grid--3">
		<div class="lt-cell">
			<h3>Emmy</h3>
			<p>Built The Daily Show&rsquo;s digital department &mdash; Emmy Award and a Cannes Lions Grand Prix.</p>
		</div>
		<div class="lt-cell">
			<h3>2&times;</h3>
			<p>Worked on the playbook that doubled subscriptions at The Wall Street Journal.</p>
		</div>
		<div class="lt-cell">
			<h3>10k+</h3>
			<p>B2B newsletter subscribers in under a year at Pluralsight, open rates 50&ndash;63%.</p>
		</div>
	</div>

	<div class="lt-panel lt-section">
		<div class="lt-wrap">
			<div class="lt-kicker">Word on the street</div>
			<p class="lt-quote">&ldquo;I also follow AntDeRosa on Twitter. I&rsquo;m a political junkie, and his interests seem to mirror my own.&rdquo;</p>
			<p class="lt-quote-attr">&mdash; Anthony Bourdain, The New York Times</p>
			<p style="margin-top:22px"><a class="lt-btn lt-btn--outline" href="<?php echo esc_url( home_url( '/testimonials/' ) ); ?>">More testimonials &rarr;</a></p>
		</div>
	</div>

	<div class="lt-grid lt-grid--2">
		<a class="lt-cell lt-cell--link" href="<?php echo esc_url( home_url( '/bio/' ) ); ?>">
			<div class="lt-kicker">My story</div>
			<h3>Who I am &amp; the work I&rsquo;ve done &rarr;</h3>
		</a>
		<a class="lt-cell lt-cell--link" href="<?php echo esc_url( home_url( '/tv-and-video/' ) ); ?>">
			<div class="lt-kicker">Portfolio</div>
			<h3>Articles, TV &amp; video &rarr;</h3>
		</a>
	</div>
</main>

<?php get_footer(); ?>
