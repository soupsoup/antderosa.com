/**
 * Lime Ticker — mobile menu toggle.
 */
(function () {
	var burger = document.querySelector('.lt-burger');
	var menu = document.getElementById('lt-mobile-menu');
	if (!burger || !menu) return;

	burger.addEventListener('click', function () {
		var open = menu.classList.toggle('is-open');
		burger.textContent = open ? '\u2715' : 'MENU';
		burger.setAttribute('aria-expanded', open ? 'true' : 'false');
		burger.style.background = open ? '#141507' : 'transparent';
		burger.style.color = open ? '#dce64d' : '#141507';
	});
})();
