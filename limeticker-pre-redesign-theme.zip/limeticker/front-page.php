<?php
/**
 * Front page: lime hero band, ticker, four proof points, lanes, case study, logos.
 */
get_header();
?>

<main>
	<div class="lt-hero-outer">
		<section class="lt-hero">
			<div class="lt-hero-copy">
				<span class="lt-kicker">Product Marketing &amp; GTM Content Leader</span>
				<h1 class="lt-h1">I turn complexity into clarity and agency.</h1>
				<p class="lt-lede">Building brand voice, owned media, and audience systems across Reuters, WSJ, The Daily Show, ON_Discourse, and Pluralsight.</p>
				<div class="lt-btn-row">
					<a class="lt-btn" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Get in touch</a>
					<a class="lt-btn lt-btn--outline" href="<?php echo esc_url( home_url( '/product-marketing/' ) ); ?>">See the work</a>
				</div>
			</div>
			<div class="lt-hero-photo">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/anthony2.png' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
			</div>
		</section>
	</div>

	<div class="lt-ticker" aria-hidden="true">
		<div class="lt-ticker-track">
			<span>AI strategy / Cybersecurity / Cloud / Market intelligence / Audience growth / GTM enablement / Product storytelling / </span><span>AI strategy / Cybersecurity / Cloud / Market intelligence / Audience growth / GTM enablement / Product storytelling / </span>
		</div>
	</div>

	<section class="lt-proof" aria-label="Proof points">
		<div class="lt-metric"><b>250%</b><span>WSJ audience growth on the playbook I helped write</span></div>
		<div class="lt-metric"><b>3.7M</b><span>WSJ digital subscribers after the growth push</span></div>
		<div class="lt-metric"><b>65%+</b><span>Pluralsight newsletter open rates, 6%+ CTR</span></div>
		<div class="lt-metric"><b>400%</b><span>Reuters social audience growth, 30 accounts</span></div>
	</section>

	<section class="lt-section lt-wrap">
		<div class="lt-section-head">
			<h2>Hire me for the operating system.</h2>
			<p>The work sits between product marketing, content strategy, market intelligence, field enablement, and audience development.</p>
		</div>
		<div class="lt-lanes">
			<a class="lt-lane" href="<?php echo esc_url( home_url( '/product-marketing/' ) ); ?>">
				<div>
					<small>01 / Product Marketing</small>
					<h3>Turn technical complexity into market clarity.</h3>
					<p>Positioning, narratives, launch programs, customer education, field-ready content, and technical translation.</p>
				</div>
				<div class="lt-arrow">Explore GTM work -&gt;</div>
			</a>
			<a class="lt-lane" href="<?php echo esc_url( home_url( '/audience/' ) ); ?>">
				<div>
					<small>02 / Audience Systems</small>
					<h3>Build trust before the sales conversation.</h3>
					<p>Independent industry intelligence, newsletters, podcasts, executive audiences, and durable owned channels.</p>
				</div>
				<div class="lt-arrow">See audience systems -&gt;</div>
			</a>
			<a class="lt-lane" href="<?php echo esc_url( home_url( '/editorial-ops/' ) ); ?>">
				<div>
					<small>03 / Editorial Operations</small>
					<h3>Make expert content repeatable at scale.</h3>
					<p>Teams, workflows, quality bars, analytics, AI-assisted production, segmentation, and publishing systems.</p>
				</div>
				<div class="lt-arrow">See the operating model -&gt;</div>
			</a>
		</div>
	</section>

	<section class="lt-case">
		<div class="lt-case-side">
			<div class="lt-eyebrow">Recent work</div>
			<h2>Pluralsight as GTM infrastructure.</h2>
		</div>
		<div class="lt-case-body">
			<p>Built Pluralsight&rsquo;s B2B strategic content and market intelligence function from scratch, creating a new audience and GTM channel for senior technology and business decision-makers.</p>
			<p>Launched three newsletters and a podcast across AI, cybersecurity, cloud computing, and workforce transformation. Sales, marketing, customer success, and enablement teams used the work to open doors, inform customer conversations, reduce churn risk, and keep acquisition pipelines warm.</p>
			<div class="lt-chips">
				<span class="lt-chip">CIO / CTO / CISO audiences</span>
				<span class="lt-chip">Market intelligence</span>
				<span class="lt-chip">Sales enablement</span>
				<span class="lt-chip">Customer retention</span>
				<span class="lt-chip">Iterable migration</span>
			</div>
		</div>
	</section>

	<div class="lt-logo-strip" aria-label="Career credibility">
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/reuters-ink3.png' ); ?>" alt="Reuters"></span>
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/wsj-ink2.png' ); ?>" alt="WSJ"></span>
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/dailyshow-ink2.png' ); ?>" alt="The Daily Show"></span>
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/ondiscourse-ink2.png' ); ?>" alt="ON_Discourse"></span>
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/pluralsight-ink2.png' ); ?>" alt="Pluralsight"></span>
		<span><img src="<?php echo esc_url( get_template_directory_uri() . '/images/logos/circa-icon-ink2.png' ); ?>" alt="Circa"></span>
	</div>
</main>

<?php get_footer(); ?>
