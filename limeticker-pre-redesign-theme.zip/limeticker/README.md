# Lime Ticker — WordPress theme

**Version 3.0.0.** Bone-white base with lime used as an accent, quieter grouped navigation, and dedicated page templates for every section of the site.

## What's new in 3.0.0

- **New palette.** Lime is now the hero band, ticker, and accent — not the whole page. Body sits on bone white (`#f6f6ef`) so long text has real contrast. Footer flipped to dark.
- **Grouped navigation.** Fifteen top-level links collapse to Work / Media / About / Newsletter / Contact with dropdowns. Sticky header.
- **New homepage hero.** Lime band, no badge pill, no watermark, headshot full-bleed to the edge. Four proof points instead of six.
- **Eight new page templates** — no more pasting HTML into the block editor:
  Product Marketing, Audience Systems, Editorial Operations, Newsletters, Podcasts, Launches, AI Builds, References.
- Body copy dropped from weight 700 to 500 throughout so headlines lead.

## Install

1. Zip the `limeticker` folder.
2. **Appearance → Themes → Add New → Upload Theme**, install, **Activate**.

Upgrading from 2.x: your pages, posts, and menu survive. You'll want to rebuild the menu (below) and switch each section page to its new template.

## Set up the menu (grouped)

Appearance → Menus. Build this structure — indent the children under their parent:

```
Work            (parent — set it to a Custom Link with URL "#")
  Product Marketing
  Audience Systems
  Editorial Operations
  Launches
  AI Builds
Media           (Custom Link "#")
  Newsletters
  Podcasts
  Video / Articles
About           (Custom Link "#")
  Bio
  Timeline
  References
  Blog
Newsletter      (Custom Link → strangerthan.beehiiv.com)
Contact         (add CSS class lt-nav-cta)
```

Parent items are toggles, not links — the theme's JS intercepts the click and opens the dropdown, so `#` is the right URL for them. Enable "CSS Classes" under Screen Options to add `lt-nav-cta`.

The logo goes home, so Home doesn't need a menu item.

## Assign the page templates

For each page: **Page Attributes → Template**, then publish.

| Page | Template | Slug it expects |
|---|---|---|
| Product Marketing | Product Marketing | `/product-marketing/` |
| Audience Systems | Audience Systems | `/audience-systems/` |
| Editorial Operations | Editorial Operations | `/editorial-operations/` |
| Newsletters | Newsletters | `/newsletters/` |
| Podcasts | Podcasts | `/podcasts/` |
| Launches | Launches | `/launches/` |
| AI Builds | AI Builds | `/ai-builds/` |
| References | References | `/testimonials/` |
| Timeline | Timeline | `/timeline/` |
| Blog | Blog (latest post) | — |

These templates render their own content, so the page body in the editor is ignored. Edit the copy in the matching `template-*.php` file — each is plain, readable HTML.

**Two slugs to fix on the live site:**

- `/editorial-operations/` currently 404s. Create the page.
- `/ai-builds-3/` is a duplicate-slug artifact. Rename it to `/ai-builds/` and add a redirect from the old URL.

Bio, Contact, and any other page still render through `page.php` (giant title + panel).

## Images

- Headshot: `images/anthony2.png`
- Logos: `images/logos/`
- AI build screenshots: `images/builds/` — eight 16:10 captures, swap freely
- ON_Discourse launch shots: `images/ondiscourse/`
- **Podcast art is hotlinked** from ondiscourse.com and pluralsight.com in `template-podcasts.php`. Download the three images, upload them to `images/podcasts/`, and swap the `src` values so you aren't depending on someone else's CDN.

## Customizing

- Colors: CSS variables at the top of `style.css` (`--lt-lime`, `--lt-ink`, `--lt-bone`, `--lt-panel`, `--lt-cream`).
- Homepage hero, ticker, proof points, lanes, case study: `front-page.php`.
- Footer CTA + social links: `footer.php`.
- Section page copy: the matching `template-*.php`.
- Timeline eras: `template-timeline.php`.
- Shared section styles used by the new templates live under the "v3 page sections" comment at the bottom of `style.css` (`.lt-band`, `.lt-stats`, `.lt-cards`, `.lt-steps`, `.lt-index`, `.lt-cta`).

## Notes

- Launches and References have client-side category filters (`js/filters.js`). They degrade to showing everything if JS is off.
- The contact form on the prototype was a mock — keep your existing form plugin on the Contact page.
- Google Fonts (Archivo + Archivo Black) load from fonts.googleapis.com. Self-host later if you prefer.
