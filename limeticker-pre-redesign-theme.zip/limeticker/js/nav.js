/**
 * Lime Ticker — mobile menu toggle + desktop dropdowns.
 */
(function () {
	var burger = document.querySelector('.lt-burger');
	var menu = document.getElementById('lt-mobile-menu');
	var header = document.querySelector('.lt-header');

	function setMenuTop() {
		var height = header ? header.getBoundingClientRect().height : 68;
		document.documentElement.style.setProperty('--lt-mobile-menu-top', height + 'px');
	}

	function setOpen(open) {
		if (!burger || !menu) return;
		setMenuTop();
		menu.classList.toggle('is-open', open);
		document.body.classList.toggle('lt-menu-open', open);
		burger.textContent = open ? '\u2715' : 'MENU';
		burger.setAttribute('aria-expanded', open ? 'true' : 'false');
		burger.style.background = open ? '#141507' : 'transparent';
		burger.style.color = open ? '#dce64d' : '#141507';
	}

	if (burger && menu) {
		burger.addEventListener('click', function () {
			setOpen(!menu.classList.contains('is-open'));
		});

		menu.addEventListener('click', function (event) {
			var link = event.target.closest('a');
			if (link && link.getAttribute('href') !== '#') {
				setOpen(false);
			}
		});

		window.addEventListener('resize', setMenuTop);
		setMenuTop();
	}

	// Desktop dropdowns: click to open, click outside or Escape to close.
	var parents = document.querySelectorAll('.lt-nav .menu-item-has-children');

	function closeAll(except) {
		Array.prototype.forEach.call(parents, function (li) {
			if (li !== except) li.classList.remove('is-open');
		});
	}

	Array.prototype.forEach.call(parents, function (li) {
		var link = li.querySelector(':scope > a');
		if (!link) return;
		link.addEventListener('click', function (e) {
			// Parent items act as toggles rather than links.
			e.preventDefault();
			var open = li.classList.contains('is-open');
			closeAll(li);
			li.classList.toggle('is-open', !open);
		});
	});

	document.addEventListener('click', function (e) {
		if (e.target.closest && e.target.closest('.lt-nav .menu-item-has-children')) return;
		closeAll(null);
	});
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') {
			closeAll(null);
			if (burger && menu) setOpen(false);
		}
	});
})();
